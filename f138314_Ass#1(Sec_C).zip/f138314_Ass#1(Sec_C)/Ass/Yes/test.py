'''
Created on Sep 3, 2016

@author: Vashdev Heerani
'''



str1="'stanford.edu','jurafsky')"
s=str1.replace(")", "")
s1,s2=s.split(",")
s=s2+"@"+s1
ns=""
for ch in s:
    if ch!="'":
        ns=ns+ch
print(ns)
